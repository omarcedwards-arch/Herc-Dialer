const express = require('express');
const twilio = require('twilio');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());

const ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
const AUTH_TOKEN  = process.env.TWILIO_AUTH_TOKEN;
const TWILIO_NUM  = process.env.TWILIO_PHONE_NUMBER;
const MY_CELL     = process.env.MY_PHONE_NUMBER;

const client = twilio(ACCOUNT_SID, AUTH_TOKEN);
const VoiceResponse = twilio.twiml.VoiceResponse;

// Health check
app.get('/', (req, res) => res.json({ status: 'Dialer server running', number: TWILIO_NUM }));

// ── 1. Initiate outbound call ──
app.post('/call', async (req, res) => {
  const { leadPhone, leadName } = req.body;
  if (!leadPhone) return res.status(400).json({ error: 'leadPhone required' });
  try {
    const baseUrl = `https://${req.get('host')}`;
    const call = await client.calls.create({
      to: MY_CELL,
      from: TWILIO_NUM,
      url: `${baseUrl}/twiml/connect?leadPhone=${encodeURIComponent(leadPhone)}&leadName=${encodeURIComponent(leadName || 'the company')}`,
      statusCallback: `${baseUrl}/call-status`,
      statusCallbackMethod: 'POST',
      statusCallbackEvent: ['completed', 'no-answer', 'busy', 'failed']
    });
    res.json({ success: true, callSid: call.sid });
  } catch (err) {
    console.error('Call error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── 2. TwiML: connect my cell to the lead ──
app.post('/twiml/connect', (req, res) => {
  const { leadPhone, leadName } = req.query;
  const twiml = new VoiceResponse();
  twiml.say({ voice: 'alice' }, `Connecting you to ${leadName}.`);
  const dial = twiml.dial({ callerId: TWILIO_NUM, timeout: 30 });
  dial.number(leadPhone);
  res.type('text/xml');
  res.send(twiml.toString());
});

// ── 3. Voicemail drop ──
app.post('/voicemail', async (req, res) => {
  const { leadPhone, vmMessage } = req.body;
  if (!leadPhone) return res.status(400).json({ error: 'leadPhone required' });
  const message = vmMessage || "Hi, this is Edwards Carriers calling about heavy equipment transportation. We move equipment nationwide and are heading to your area soon. If you have any equipment that needs to be relocated, please give us a call back. Thank you.";
  try {
    const call = await client.calls.create({
      to: leadPhone,
      from: TWILIO_NUM,
      url: `https://${req.get('host')}/twiml/voicemail?msg=${encodeURIComponent(message)}`
    });
    res.json({ success: true, callSid: call.sid });
  } catch (err) {
    console.error('Voicemail error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── 4. TwiML: play voicemail message ──
app.post('/twiml/voicemail', (req, res) => {
  const msg = req.query.msg || "Please call us back regarding heavy equipment transport.";
  const twiml = new VoiceResponse();
  twiml.say({ voice: 'alice', rate: '90%' }, msg);
  res.type('text/xml');
  res.send(twiml.toString());
});

// ── 5. Incoming call forwarding ──
app.post('/incoming', (req, res) => {
  const twiml = new VoiceResponse();
  twiml.say({ voice: 'alice' }, 'Please hold while we connect your call.');
  const dial = twiml.dial({ timeout: 20 });
  dial.number(MY_CELL);
  res.type('text/xml');
  res.send(twiml.toString());
});

// ── 6. Phone number lookup (mobile vs landline) ──
// POST /lookup  { phones: ["+15551234567", ...] }
// Returns { results: { "+15551234567": "mobile", ... } }
app.post('/lookup', async (req, res) => {
  const { phones } = req.body;
  if (!phones || !phones.length) return res.status(400).json({ error: 'phones array required' });

  const results = {};
  for (const phone of phones) {
    try {
      const lookup = await client.lookups.v2.phoneNumbers(phone).fetch({ fields: 'line_type_intelligence' });
      const lineType = lookup.lineTypeIntelligence && lookup.lineTypeIntelligence.type
        ? lookup.lineTypeIntelligence.type
        : 'unknown';
      // Normalize to mobile / landline / voip / unknown
      if (lineType === 'mobile' || lineType === 'personal') results[phone] = 'Mobile';
      else if (lineType === 'landline' || lineType === 'fixedVoip') results[phone] = 'Landline';
      else if (lineType === 'voip' || lineType === 'nonFixedVoip') results[phone] = 'VoIP';
      else results[phone] = 'Unknown';
    } catch (err) {
      console.error('Lookup error for', phone, ':', err.message);
      results[phone] = 'Unknown';
    }
  }
  res.json({ success: true, results });
});

// ── 7. Call status log ──
app.post('/call-status', (req, res) => {
  console.log('Call status:', req.body.CallStatus, '| SID:', req.body.CallSid, '| To:', req.body.To);
  res.sendStatus(200);
});

// ── 8. Bright Data search proxy ──
// POST /search  { keyword: "heavy equipment rental", city: "Dallas, TX" }
// Returns { results: [{ name, address, phone, website, mapsUrl }] }
app.post('/search', async (req, res) => {
  const { keyword, city } = req.body;
  if (!keyword || !city) return res.status(400).json({ error: 'keyword and city required' });

  const BD_API_KEY = process.env.BD_API_KEY || '41e115fd-9ac7-472e-a1dd-fe758918ff22';
  const BD_ZONE    = process.env.BD_ZONE    || 'ec_equipment';

  const query = encodeURIComponent(`${keyword} ${city}`);
  // Use Google Maps search — Bright Data Web Unlocker fetches the page
  const targetUrl = `https://www.google.com/maps/search/${query}`;

  try {
    const bdRes = await fetch('https://api.brightdata.com/request', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${BD_API_KEY}`
      },
      body: JSON.stringify({
        zone: BD_ZONE,
        url: targetUrl,
        format: 'raw'
      })
    });

    const html = await bdRes.text();

    // Parse business listings from Google Maps HTML
    // Google Maps embeds data in JSON-LD and data attributes
    const results = [];
    const seenNames = new Set();

    // Pattern 1: Extract from window.APP_INITIALIZATION_STATE or similar JSON blobs
    // Pattern 2: Look for structured data in the HTML
    // We parse common patterns from Maps HTML response

    // Extract business names using regex patterns on Maps HTML
    // Names appear as: "name":"Business Name" in the embedded JSON
    const namePattern = /\\?"name\\?":\s*\\?"([^"\\]{3,80})\\?"/g;
    const phonePattern = /\\?"(?:phone|formatted_phone_number|phoneNumbers?)\\?":\s*\\?"(\+?[\d\s\(\)\-\.]{7,20})\\?"/g;
    const addrPattern  = /\\?"(?:address|formatted_address|vicinity)\\?":\s*\\?"([^"\\]{5,120})\\?"/g;
    const urlPattern   = /\\?"(?:website|url)\\?":\s*\\?"(https?:\/\/[^"\\]{4,80})\\?"/g;

    let nameMatch, phones = [], addrs = [], urls = [];
    while ((nameMatch = namePattern.exec(html)) !== null) {
      const name = nameMatch[1].replace(/\\n/g,' ').trim();
      // Filter out noise — keep business-looking names
      if (name.length < 3 || name.length > 80) continue;
      if (/^(https?|www\.|[0-9]|\{|\[)/.test(name)) continue;
      if (seenNames.has(name.toLowerCase())) continue;
      seenNames.add(name.toLowerCase());
      results.push({ name, address: '', phone: null, website: null, mapsUrl: null });
      if (results.length >= 20) break;
    }

    // Separately extract phones/addresses to enrich results
    let pm; const phoneList = [];
    while ((pm = phonePattern.exec(html)) !== null) phoneList.push(pm[1].trim());
    let am; const addrList = [];
    while ((am = addrPattern.exec(html)) !== null) addrList.push(am[1].trim());
    let um; const urlList = [];
    while ((um = urlPattern.exec(html)) !== null) {
      const u = um[1].trim();
      if (!/google\.com|gstatic|googleapis|schema\.org|w3\.org/.test(u)) urlList.push(u);
    }

    // Assign enrichment data positionally
    results.forEach((r, i) => {
      r.phone   = phoneList[i] || null;
      r.address = addrList[i]  || '';
      r.website = urlList[i]   || null;
      r.mapsUrl = `https://www.google.com/maps/search/${encodeURIComponent(r.name + ' ' + city)}`;
      r.placeId = `bd_${Date.now()}_${i}`;
    });

    console.log(`/search "${keyword}" in "${city}" → ${results.length} results (BD status: ${bdRes.status})`);
    res.json({ success: true, results, count: results.length });

  } catch (err) {
    console.error('BD search error:', err.message);
    res.status(500).json({ error: err.message, results: [] });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Dialer server running on port ${PORT}`));
